#!/usr/bin/env python3
import json,re,sqlite3
from pathlib import Path
ROOT=Path(__file__).parent
pages=[json.loads(x) for x in (ROOT/'pages/pages.jsonl').read_text(encoding='utf-8').splitlines()]
markers=re.compile(r'\b(OVERALL FORMULA|FINAL DOUGH|Рецептура\s+хлеба|Рецептура|РЕЦЕПТУРА|РЕЦЕПТЫ|Ингредиенты|ИНГРЕДИЕНТ)\b',re.I)
title_patterns=[re.compile(r'\b(?:Рецептура\s+хлеба\s*[«"]([^»"]+)[»"]|ХЛЕБ\s*[«"]([^»"]+)[»"]|([A-Z][A-Z][A-Z][A-Z\s«»"-]{3,}))',re.I)]

def title_from(text):
    for p in title_patterns:
        m=p.search(text)
        if m:
            for g in m.groups():
                if g and len(g.strip())>2: return re.sub(r'\s+',' ',g.strip(' «»"'))
    lines=[re.sub(r'\s+',' ',x.strip()) for x in text.splitlines() if x.strip()]
    for x in lines[:12]:
        if len(x)<=100 and (x.isupper() or 'bread' in x.lower() or 'rye' in x.lower()): return x.strip(' «»"')
    return None

out=[]; i=0; seq={}
while i<len(pages):
    r=pages[i]
    if not markers.search(r['text']): i+=1; continue
    sid=r['source_id']; key=(sid,r['pdf_page_number']); seq[sid]=seq.get(sid,0)+1
    end=i+1
    # collect continuation pages until another formula marker, max 4 pages
    while end<len(pages) and pages[end]['source_id']==sid and end<i+4 and not markers.search(pages[end]['text']): end+=1
    # If next page is a new formula marker, stop before it
    texts=[pages[j]['text'] for j in range(i,end)]
    out.append({
      'formula_id':f'{sid}:formula:{seq[sid]:04d}', 'source_id':sid,
      'title_candidate':title_from(r['text']),
      'start_pdf_page':r['pdf_page_number'],'start_printed_page':r['printed_page_number'],
      'page_ids':[pages[j]['id'] for j in range(i,end)],
      'raw_text':'\n\n'.join(texts), 'status':'needs_validation',
      'validation_note':'Structural extraction only; quantities/process are not yet validated against the source.'})
    i=end
p=ROOT/'formulas/formula_groups.jsonl'; p.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in out)+'\n',encoding='utf-8')
print('formula groups:',len(out))

# evidence index: page/chunk -> formula group, and claims -> candidate pages when concept terms overlap
DB=ROOT/'retrieval/rye.sqlite'; con=sqlite3.connect(DB); cur=con.cursor()
cur.executescript('''CREATE TABLE IF NOT EXISTS formula_groups(formula_id TEXT PRIMARY KEY,source_id TEXT,title_candidate TEXT,start_pdf_page INTEGER,start_printed_page INTEGER,page_ids_json TEXT,raw_text TEXT,status TEXT,validation_note TEXT);
CREATE TABLE IF NOT EXISTS evidence_links(evidence_id TEXT, target_type TEXT, target_id TEXT, source_id TEXT, page_id TEXT, relation TEXT, PRIMARY KEY(evidence_id,target_type,target_id));''')
for x in out:
 cur.execute('INSERT OR REPLACE INTO formula_groups VALUES(?,?,?,?,?,?,?,?,?)',(x['formula_id'],x['source_id'],x['title_candidate'],x['start_pdf_page'],x['start_printed_page'],json.dumps(x['page_ids']),x['raw_text'],x['status'],x['validation_note']))
 for pid in x['page_ids']:
  cur.execute('INSERT OR REPLACE INTO evidence_links VALUES(?,?,?,?,?,?)',(pid,'formula_group',x['formula_id'],x['source_id'],pid,'source_page'))
# seed claims: link claims to same-source page candidates by concept terms
claims=[]
cp=ROOT/'seed_claims.jsonl'
if cp.exists(): claims=[json.loads(x) for x in cp.read_text(encoding='utf-8').splitlines() if x.strip()]
for c in claims:
    terms=set(re.findall(r'[\w-]{4,}',(c.get('concept','')+' '+c.get('value','')).lower()))
    for r in pages:
        if r['source_id']!=c.get('source_id'): continue
        low=r['text'].lower()
        score=sum(1 for t in terms if t in low)
        if score>=1 and c.get('page_number') and r['pdf_page_number']==c['page_number']:
            cur.execute('INSERT OR REPLACE INTO evidence_links VALUES(?,?,?,?,?,?)',(r['id'],'claim',c['id'],r['source_id'],r['id'],'page_match'))
con.commit(); con.close()
print('evidence links built')
