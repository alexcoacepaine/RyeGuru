# RYE MCP App — deployment

The server now uses the current Streamable HTTP pattern and the MCP Apps
two-part tool/resource registration.

Endpoint:
`/mcp`

Local:
1. `npm install`
2. `npm run build`
3. `npm run serve`
4. MCP endpoint: `http://localhost:8787/mcp`

Production:
- build the container;
- expose it behind HTTPS;
- point the ChatGPT/App environment at the HTTPS `/mcp` endpoint.

The SQLite database is read-only. Formula candidates remain explicitly
`needs_validation`; formula scaling is blocked until validation.

The current MCP SDK documents Streamable HTTP as the recommended remote
transport. The MCP Apps examples use `registerAppTool` + `registerAppResource`.
