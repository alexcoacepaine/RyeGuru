# RYE App — deployment checklist

## Local package
- [x] Corpus ingestion
- [x] Page/chunk index
- [x] Formula candidate layer
- [x] Knowledge layer
- [x] Evidence graph
- [x] MCP tool contract
- [x] App manifest/UI contract

## External deployment still required
- [ ] Host the MCP service at a reachable HTTPS endpoint
- [ ] Connect the hosted MCP endpoint to the ChatGPT app/developer environment
- [ ] Test tool discovery and tool invocation
- [ ] Test citation/evidence behavior
- [ ] Test missing-evidence fallback
- [ ] Test conflicting sources
- [ ] Test formula validation gate
- [ ] Test formula scaling gate
- [ ] Publish/distribute according to the current ChatGPT app/plugin availability rules

OpenAI's current developer site describes Plugins as extending ChatGPT and Codex
with skills, MCP servers, and optional UI, and its showcase includes WebMCP apps.
