import json,re
from pathlib import Path
src=Path(__file__).parent/'pages/pages.jsonl'; out=Path(__file__).parent/'formulas/formula_candidates.jsonl'
patterns=[r'OVERALL FORMULA',r'FINAL DOUGH',r'FORMULA',r'RECIPE',r'РЕЦЕПТ',r'РЕЦЕПТУРА',r'РЕЦЕПТЫ',r'ИНГРЕДИЕНТ']
rows=[]
for line in src.read_text(encoding='utf-8').splitlines():
 r=json.loads(line); t=r['text']
 if any(re.search(p,t,re.I) for p in patterns):
  rows.append({'candidate_id':r['id']+':formula_candidate','source_id':r['source_id'],'page_id':r['id'],'pdf_page':r['pdf_page_number'],'printed_page':r['printed_page_number'],'text':t,'status':'needs_validation'})
out.write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows)+'\n',encoding='utf-8')
print('formula candidates:',len(rows))
