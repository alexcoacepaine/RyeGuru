import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).parent
cases=json.loads((ROOT/'evaluation.json').read_text(encoding='utf8'))
passed=[]
for c in cases.get('tests',[]):
    q=c.get('question') or c.get('query') or c.get('prompt') or c.get('name','')
    if not q: continue
    p=subprocess.run([sys.executable,str(ROOT/'retrieval/rye_query.py'),q,'-n','3','--json'],capture_output=True,text=True)
    ok=p.returncode==0 and bool(json.loads(p.stdout).get('results',[])) if p.stdout else False
    passed.append({'id':c.get('id',c.get('name','unnamed')),'retrieval_smoke':ok})
print(json.dumps({'tests_run':len(passed),'retrieval_smoke_passed':sum(x['retrieval_smoke'] for x in passed),'results':passed},ensure_ascii=False,indent=2))
