#!/usr/bin/env python3
"""
RYE page-aware ingestion bootstrap.

This script intentionally does NOT infer missing page numbers from prose.
For sources where page markers are unavailable in extracted text, it records
page_number as null and preserves the source text for a later page-aware pass.
"""

from pathlib import Path
import argparse, hashlib, json, re

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def split_sections(text):
    lines = text.splitlines()
    sections, current, buf = [], None, []
    heading = re.compile(r"^(?:CHAPTER|CAPITOLUL|SECTION|SOURDOUGH|SCALD|SOAKER|FINAL DOUGH|OVERALL FORMULA|BAKER.?S PERCENTAGES)\b", re.I)
    for line in lines:
        if heading.search(line.strip()):
            if buf:
                sections.append({"section": current or "UNSECTIONED", "text": "\n".join(buf).strip()})
                buf = []
            current = line.strip()
        buf.append(line)
    if buf:
        sections.append({"section": current or "UNSECTIONED", "text": "\n".join(buf).strip()})
    return [s for s in sections if s["text"]]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source_dir")
    ap.add_argument("output_dir")
    args = ap.parse_args()
    src = Path(args.source_dir)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    records = []
    for p in sorted(src.glob("*.txt")):
        text = p.read_text(encoding="utf-8", errors="replace")
        for i, sec in enumerate(split_sections(text)):
            rec = {
                "id": f"{p.stem}:{i+1}",
                "source_file": p.name,
                "page_number": None,
                "section": sec["section"],
                "text": sec["text"],
                "sha256": sha256(p),
                "status": "page_number_unresolved"
            }
            records.append(rec)

    (out / "sections.jsonl").write_text(
        "\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n",
        encoding="utf-8"
    )
    print(f"Wrote {len(records)} section records to {out/'sections.jsonl'}")

if __name__ == "__main__":
    main()
