# RYE Knowledge Layer v0.1

This layer contains **retrieval candidates**, not validated knowledge claims.

Entities are detected from source text and linked to source/page coordinates. No relationship is asserted merely because terms co-occur.

## Statuses
- `candidate_only`: requires source-level validation.
- `validated`: reserved for manually/source-verified relations.

The layer is deliberately conservative: co-occurrence is not treated as causality, recipe instruction, dosage, temperature, time, or technological rule.
