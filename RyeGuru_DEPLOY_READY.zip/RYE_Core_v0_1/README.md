# RYE Core v0.1

Corpus-grounded retrieval core for rye baking.

## Sources included

1. The Rye Baker
2. Hamelman — Sourdough Rye Breads
3. Teh-Hleb 1959
4. Manualul brutarului militar NKVD — 1944
5. Pâine de secară — ABC-ul brutarului (Kiriloff)
6. Weinheim Bread Language

## Architecture

`source files → normalized page extraction → chunks → lexical retrieval → evidence → constrained answer`

The corpus is authoritative for RYE-domain claims. Missing information is not reconstructed from general knowledge.

## Current build

- 6/6 sources locally detected
- 881 PDF pages extracted
- 873 retrieval chunks
- SQLite FTS5 retrieval index
- 391 formula/recipe candidate pages flagged for manual validation
- ABC-ul lui Kiriloff is included as `abc_secara`
- NKVD 1944 is included as `nkvd_1944`

See `RETRIEVAL.md` for the retrieval layer and `RYE_ANSWER_POLICY.md` for answer constraints.


## MCP stage
The RYE backend contract and corpus-only answer policy are in `mcp/`. The transport adapter is intentionally separated from retrieval so the same evidence rules apply in ChatGPT Apps.
