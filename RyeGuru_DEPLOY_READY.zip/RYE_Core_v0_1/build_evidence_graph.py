#!/usr/bin/env python3
import json, sqlite3, hashlib
from pathlib import Path
ROOT=Path('/mnt/data/RYE_Core_v0_1'); DB=ROOT/'retrieval/rye.sqlite'

def load(path):
    if not path.exists(): return []
    return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
claims=load(ROOT/'seed_claims.jsonl'); formulas=load(ROOT/'formulas/formula_groups.jsonl'); ev=load(ROOT/'evidence/seed_evidence_candidates.jsonl')
con=sqlite3.connect(DB); cur=con.cursor()
cur.executescript('''
CREATE TABLE IF NOT EXISTS claims(claim_id TEXT PRIMARY KEY, concept TEXT, value TEXT, condition TEXT, type TEXT, source_id TEXT, page INTEGER, section TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS formulas(formula_id TEXT PRIMARY KEY, source_id TEXT, title_candidate TEXT, start_page INTEGER, status TEXT, raw_text TEXT);
CREATE TABLE IF NOT EXISTS evidence(evidence_id TEXT PRIMARY KEY, source_id TEXT, page INTEGER, section TEXT, text TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS edges(edge_id TEXT PRIMARY KEY, from_type TEXT, from_id TEXT, to_type TEXT, to_id TEXT, relation TEXT);
''')
for c in claims:
    cid=c.get('claim_id') or hashlib.sha1(json.dumps(c,sort_keys=True).encode()).hexdigest()[:16]
    cur.execute('INSERT OR REPLACE INTO claims VALUES(?,?,?,?,?,?,?,?,?)',(cid,c.get('concept'),c.get('value'),c.get('condition'),c.get('type'),c.get('source_id'),c.get('page_number'),c.get('section'),c.get('status')))
for f in formulas:
    cur.execute('INSERT OR REPLACE INTO formulas VALUES(?,?,?,?,?,?)',(f['formula_id'],f['source_id'],f.get('title_candidate'),f.get('start_pdf_page'),f.get('status'),f.get('raw_text')))
for e in ev:
    eid=e.get('evidence_id') or e.get('id') or hashlib.sha1(json.dumps(e,sort_keys=True).encode()).hexdigest()[:16]
    cur.execute('INSERT OR REPLACE INTO evidence VALUES(?,?,?,?,?,?)',(eid,e.get('source_id'),e.get('page_number') or e.get('pdf_page'),e.get('section'),e.get('text',''),e.get('status','candidate')))
    # link evidence to its source page when page is known
    if e.get('source_id') and (e.get('page_number') or e.get('pdf_page')):
        pid=f"{e['source_id']}:p{e.get('pdf_page') or e.get('page_number')}"
        edge=hashlib.sha1(f'evidence:{eid}->page:{pid}'.encode()).hexdigest()[:20]
        cur.execute('INSERT OR IGNORE INTO edges VALUES(?,?,?,?,?,?)',(edge,'evidence',eid,'page',pid,'supports'))
for c in claims:
    cid=c.get('claim_id') or hashlib.sha1(json.dumps(c,sort_keys=True).encode()).hexdigest()[:16]
    if c.get('source_id') and c.get('page_number'):
        pid=f"{c['source_id']}:p{c['page_number']}"
        edge=hashlib.sha1(f'claim:{cid}->page:{pid}'.encode()).hexdigest()[:20]
        cur.execute('INSERT OR IGNORE INTO edges VALUES(?,?,?,?,?,?)',(edge,'claim',cid,'page',pid,'grounded_in'))
for f in formulas:
    fid=f['formula_id']; pid=f"{f['source_id']}:p{f['start_pdf_page']}"
    edge=hashlib.sha1(f'formula:{fid}->page:{pid}'.encode()).hexdigest()[:20]
    cur.execute('INSERT OR IGNORE INTO edges VALUES(?,?,?,?,?,?)',(edge,'formula',fid,'page',pid,'extracted_from'))
con.commit()
counts={}
for t in ('claims','formulas','evidence','edges'):
    counts[t]=cur.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
con.close()
(ROOT/'evidence/EVIDENCE_GRAPH.md').write_text('# RYE Evidence Graph v0.1\n\nEvery claim/formula/evidence record is linked to a source/page where available. Extracted formulas remain `needs_validation`; no extraction is promoted to documented fact automatically.\n\nCounts: '+json.dumps(counts,ensure_ascii=False)+'\n',encoding='utf-8')
print(counts)
