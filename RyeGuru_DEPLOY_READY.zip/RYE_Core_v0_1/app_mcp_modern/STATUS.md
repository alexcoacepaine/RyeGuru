# RYE modern MCP App

Prepared against the current MCP Apps architecture:
- App tool + UI resource registration
- `ui://` resource
- structured tool output + text fallback
- corpus retrieval remains server-side

The package intentionally does not claim to be deployed. The remaining external
step is to connect `searchRye()` to the existing RYE SQLite retrieval service,
then host the MCP endpoint over HTTPS and connect it to ChatGPT.
