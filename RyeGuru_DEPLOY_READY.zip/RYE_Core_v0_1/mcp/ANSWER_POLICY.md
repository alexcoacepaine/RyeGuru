# RYE MCP — answer policy

- Retrieval exclusiv din corpusul RYE.
- Afirmațiile factuale trebuie să poată fi urmărite la sursă + pagină/pasaj.
- Lipsa dovezii: „Nu este documentat în sursele RYE disponibile.”
- Nu se reconciliază automat surse aflate în conflict.
- Candidate formulas ≠ validated formulas.
- Scaling numai mecanic și numai pe formule validate.
- Nu se adaugă parametri tehnologici nesusținuți.
