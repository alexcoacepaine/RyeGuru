# RYE ChatGPT App

This directory contains the application-facing package for RYE Core.

Architecture:
ChatGPT → RYE MCP → hybrid retrieval → evidence graph → RYE corpus

The MCP server is the authoritative interface. The UI layer must never bypass
the evidence/retrieval layer or introduce corpus claims of its own.

Deployment still requires a hosted MCP endpoint and the corresponding
ChatGPT/App configuration; those cannot be published from this local artifact alone.
