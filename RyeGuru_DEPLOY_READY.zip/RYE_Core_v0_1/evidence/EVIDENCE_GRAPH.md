# RYE Evidence Graph v0.1

Every claim/formula/evidence record is linked to a source/page where available. Extracted formulas remain `needs_validation`; no extraction is promoted to documented fact automatically.

Counts: {"claims": 7, "formulas": 224, "evidence": 7, "edges": 232}
