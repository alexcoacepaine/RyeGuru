# RYE Core — Evidence Graph + MCP readiness

## Evidence Graph

The graph is persisted in `retrieval/rye.sqlite` with nodes for sources/pages/chunks, claims, formulas and evidence, plus typed edges. A claim or formula is never promoted to `documented` merely because it was extracted.

## MCP contract

The backend interface in `app_mcp.ts` exposes five operations:
- search
- evidence
- formula
- compare
- calculate

`calculate` is intended only for mechanical scaling of an already validated formula. It must not add ingredients or invent process parameters.

## Current boundary

The repository is ready for an MCP adapter, but it is not yet a published ChatGPT app. Publication requires connecting the backend to an MCP/App SDK deployment and configuring the app in ChatGPT.
