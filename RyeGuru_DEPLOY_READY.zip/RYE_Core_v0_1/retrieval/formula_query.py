#!/usr/bin/env python3
import argparse,json,sqlite3
from pathlib import Path
DB=Path(__file__).with_name('rye.sqlite')
def search(q,limit=10,source=None):
 con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
 sql='SELECT formula_id,source_id,title_candidate,start_pdf_page,start_printed_page,status,raw_text FROM formula_groups WHERE (title_candidate LIKE ? OR raw_text LIKE ?)' 
 args=[f'%{q}%',f'%{q}%']
 if source: sql+=' AND source_id=?'; args.append(source)
 sql+=' LIMIT ?'; args.append(limit)
 rows=[dict(r) for r in con.execute(sql,args)]; con.close(); return rows
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('query'); ap.add_argument('-n','--limit',type=int,default=10); ap.add_argument('--source'); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
 rows=search(a.query,a.limit,a.source)
 print(json.dumps(rows,ensure_ascii=False,indent=2) if a.json else '\n\n'.join(f"[{r['formula_id']} | {r['title_candidate']} | p.{r['start_printed_page'] or r['start_pdf_page']} | {r['status']}]\n{r['raw_text'][:5000]}" for r in rows))
