#!/usr/bin/env python3
"""RYE hybrid retrieval prototype: SQLite FTS5 + TF-IDF lexical-semantic similarity.
This is not an LLM embedding index; it is deterministic and source-grounded.
"""
import sqlite3,re,sys,json
from pathlib import Path
DB=Path(__file__).with_name('rye.sqlite')

def toks(s): return re.findall(r'\w+',s.lower(),re.UNICODE)
def search(q,limit=8):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    # FTS candidate pool
    fts=' OR '.join('"'+t.replace('"','')+'"' for t in toks(q)) or '""'
    rows=list(con.execute('SELECT c.id,c.source_id,c.page_id,c.pdf_page,c.printed_page,c.text,bm25(chunks_fts) score FROM chunks_fts JOIN chunks c ON chunks_fts.id=c.id WHERE chunks_fts MATCH ? ORDER BY score LIMIT 40',(fts,)))
    qset=set(toks(q)); scored=[]
    for r in rows:
        words=toks(r['text']); overlap=len(qset & set(words)); density=overlap/max(1,len(qset))
        # lower bm25 is better; normalize into 0..1-ish
        bm=max(0.0,min(1.0,1/(1+max(0,float(r['score'])))))
        final=0.65*bm+0.35*density
        scored.append((final,r))
    scored.sort(key=lambda x:x[0],reverse=True)
    out=[]
    for s,r in scored[:limit]:
        out.append({'score':round(s,4),'source_id':r['source_id'],'page':r['printed_page'] or r['pdf_page'],'pdf_page':r['pdf_page'],'chunk_id':r['id'],'text':r['text']})
    con.close(); return out
if __name__=='__main__':
    q=' '.join(sys.argv[1:]); print(json.dumps({'query':q,'results':search(q)},ensure_ascii=False,indent=2))
