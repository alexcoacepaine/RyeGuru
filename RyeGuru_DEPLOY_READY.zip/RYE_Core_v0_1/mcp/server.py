"""RYE MCP transport-independent backend contract."""
MISSING = "Nu este documentat în sursele RYE disponibile."

TOOLS = {
    "search_rye": {
        "description": "Caută exclusiv în corpusul RYE și returnează pasaje cu sursă și pagină.",
        "input": {"query": "string", "limit": "integer?"}},
    "get_rye_evidence": {
        "description": "Returnează dovezile pentru o sursă și o pagină exactă.",
        "input": {"source_id": "string", "page_number": "integer"}},
    "get_formula": {
        "description": "Returnează numai formule validate.",
        "input": {"formula_id": "string"}},
    "compare_sources": {
        "description": "Prezintă separat ce afirmă sursele despre același subiect.",
        "input": {"topic": "string", "source_ids": "string[]?"}},
    "calculate_formula": {
        "description": "Scalează mecanic numai formule validate.",
        "input": {"formula_id": "string", "target_factor": "number"}},
}
