# RYE Answer Policy v0.1

1. Use retrieved RYE evidence as the factual basis.
2. Preserve source terminology and source-specific framing.
3. Do not invent quantities, temperatures, times, proportions, ingredients or procedures.
4. Do not silently reconcile conflicting sources.
5. For formulas, preserve stages, quantities and baker's percentages when documented.
6. Every substantive factual answer should retain source/page provenance.
7. Distinguish DOCUMENTAT / INFERENȚĂ / IPOTEZĂ / PROPUNERE EXPERIMENTALĂ / INFORMAȚIE EXTERNĂ.
8. If the corpus does not document the requested point, answer exactly:
   „Nu este documentat în sursele RYE disponibile.”
