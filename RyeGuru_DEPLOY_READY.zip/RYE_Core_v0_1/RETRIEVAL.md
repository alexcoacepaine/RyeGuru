# RYE Retrieval — v0.1

Local retrieval layer built from the six RYE sources.

## Current pipeline

`original files → PDF normalization → page extraction → paragraph chunks → SQLite FTS5 → evidence results`

### Corpus size
- 6 sources
- 881 PDF pages extracted
- 873 retrieval chunks
- 391 formula/recipe candidate pages flagged for validation

## Evidence discipline

Retrieval returns the source text together with source ID and page coordinates. A candidate formula is **not** treated as validated merely because it matched a formula/recipe heading.

The response layer must:
1. retrieve evidence;
2. preserve source wording and quantities;
3. cite source + page;
4. preserve conflicts between sources;
5. say `Nu este documentat în sursele RYE disponibile.` when evidence is absent.

## Local query

```bash
python retrieval/rye_query.py "scald" -n 8
python retrieval/rye_query.py "картофель" --source abc_secara
```

The SQLite database is `retrieval/rye.sqlite`.
