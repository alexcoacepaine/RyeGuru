#!/usr/bin/env python3
import sqlite3, sys, json, re
from pathlib import Path
DB=Path(__file__).with_name('rye.sqlite')

def qfts(q):
    # quote each token for robust FTS matching; use OR
    toks=re.findall(r'\S+',q.strip())
    return ' OR '.join('"'+t.replace('"','')+'"' for t in toks) or '""'

def search(q,limit=8,source=None):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    sql='''SELECT c.id,c.source_id,c.page_id,c.pdf_page,c.printed_page,c.text,bm25(chunks_fts) score
           FROM chunks_fts JOIN chunks c ON chunks_fts.id=c.id
           WHERE chunks_fts MATCH ?'''
    args=[qfts(q)]
    if source:
      sql+=' AND c.source_id=?'; args.append(source)
    sql+=' ORDER BY score LIMIT ?'; args.append(limit)
    rows=[dict(r) for r in con.execute(sql,args)]
    con.close(); return rows
if __name__=='__main__':
 q=' '.join(sys.argv[1:])
 for r in search(q):
  print(json.dumps(r,ensure_ascii=False))
