// RYE MCP/App bootstrap — interface only.
// Connect these handlers to the RYE retrieval backend after ingestion.

export type RyeEvidence = {
  source_id: string;
  title: string;
  page_number?: number | null;
  section?: string | null;
  evidence_ref: string;
  text: string;
  score?: number;
};

export type RyeFormula = {
  id: string;
  bread_name: string;
  source_id: string;
  source_page?: number | null;
  stages: Array<{
    name: string;
    ingredients: Array<{
      name: string;
      grams?: number | null;
      baker_percentage?: number | null;
    }>;
    procedure?: string;
  }>;
};

export interface RyeBackend {
  search(query: string, opts?: { sourceIds?: string[]; maxResults?: number }): Promise<RyeEvidence[]>;
  evidence(ref: string): Promise<RyeEvidence | null>;
  formula(nameOrId: string): Promise<RyeFormula | null>;
  compare(topic: string, sourceIds?: string[]): Promise<RyeEvidence[]>;
  calculate(formulaId: string, scaleFactor: number): Promise<RyeFormula>;
}
