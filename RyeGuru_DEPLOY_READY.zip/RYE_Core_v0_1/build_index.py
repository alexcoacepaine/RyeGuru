from pathlib import Path
import fitz, json, hashlib, re, sqlite3, shutil

ROOT=Path('/mnt/data/RYE_Core_v0_1')
PDF=ROOT/'pages/pdf'
PAGES=ROOT/'pages/pages.jsonl'
CHUNKS=ROOT/'pages/chunks.jsonl'
DB=ROOT/'retrieval/rye.sqlite'
PAGES.parent.mkdir(exist_ok=True); (ROOT/'retrieval').mkdir(exist_ok=True)
source_map={
'The rye baker.pdf':'the_rye_baker',
'Hamelman-Sourdough-Rye - Unknown.pdf':'hamelman_sourdough_rye',
'Weinheim_Bread_Language_.pdf':'weinheim_bread_language',
'teh-hleb-1959 - Necunoscut ro.pdf':'teh_hleb_1959',
'voin-hlebopek-1944-manualul-brutarului-militar-nkvd.pdf':'nkvd_1944',
'Pâine de secară — ABC-ul brutarului” Ser.pdf':'abc_secara',
}
orig={
 'the_rye_baker':'The rye baker.odt','hamelman_sourdough_rye':'Hamelman-Sourdough-Rye - Unknown.odt','weinheim_bread_language':'Weinheim_Bread_Language_.pdf','teh_hleb_1959':'teh-hleb-1959 - Necunoscut ro.docx','nkvd_1944':'voin-hlebopek-1944-manualul-brutarului-militar-nkvd.doc','abc_secara':'Pâine de secară — ABC-ul brutarului” Ser.odt'}

def sha256(p):
 h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

def printed_page(text):
 lines=[x.strip() for x in text.splitlines() if x.strip()]
 # Conservative: accept only a 2+ digit standalone footer candidate near page end.
 for x in reversed(lines[-10:]):
  m=re.fullmatch(r'(\d{2,4})',x)
  if m: return int(m.group(1))
  m=re.search(r'\b(?:Page|PAGE|p\.|стр\.|Стр\.)\s*(\d{1,4})\b',x)
  if m: return int(m.group(1))
 return None

def clean(text):
 text=text.replace('\x00','')
 return '\n'.join(line.rstrip() for line in text.splitlines()).strip()

page_records=[]; chunk_records=[]
for pdf in sorted(PDF.glob('*.pdf')):
 if pdf.name not in source_map: continue
 sid=source_map[pdf.name]; doc=fitz.open(pdf)
 for i,page in enumerate(doc):
  text=clean(page.get_text('text'))
  rec={'id':f'{sid}:p{i+1}','source_id':sid,'source_file':orig[sid], 'pdf_page_number':i+1,'printed_page_number':printed_page(text),'text':text,'source_sha256':sha256(Path('/mnt/data')/orig[sid]),'status':'page_aware_extraction' if text else 'empty_text'}
  page_records.append(rec)
  # paragraph-aware chunks; keep moderate size without rewriting text
  paras=[p.strip() for p in re.split(r'\n\s*\n',text) if p.strip()]
  if not paras and text: paras=[text]
  buf=''; idx=0
  for para in paras:
   if len(buf)+len(para)+2>4500 and buf:
    idx+=1; chunk_records.append({'id':f'{sid}:p{i+1}:c{idx}','source_id':sid,'page_id':rec['id'],'pdf_page_number':i+1,'printed_page_number':rec['printed_page_number'],'text':buf.strip()}); buf=''
   buf += ('\n\n' if buf else '')+para
  if buf:
   idx+=1; chunk_records.append({'id':f'{sid}:p{i+1}:c{idx}','source_id':sid,'page_id':rec['id'],'pdf_page_number':i+1,'printed_page_number':rec['printed_page_number'],'text':buf.strip()})
PAGES.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in page_records)+'\n',encoding='utf-8')
CHUNKS.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in chunk_records)+'\n',encoding='utf-8')
if DB.exists(): DB.unlink()
con=sqlite3.connect(DB); cur=con.cursor()
cur.executescript('''CREATE TABLE sources(source_id TEXT PRIMARY KEY,file TEXT,sha256 TEXT); CREATE TABLE pages(id TEXT PRIMARY KEY,source_id TEXT,pdf_page INTEGER,printed_page INTEGER,text TEXT); CREATE TABLE chunks(id TEXT PRIMARY KEY,source_id TEXT,page_id TEXT,pdf_page INTEGER,printed_page INTEGER,text TEXT); CREATE VIRTUAL TABLE chunks_fts USING fts5(id UNINDEXED,source_id UNINDEXED,text,content='chunks',content_rowid='rowid');''')
for sid,file in orig.items(): cur.execute('INSERT INTO sources VALUES(?,?,?)',(sid,file,sha256(Path('/mnt/data')/file)))
for r in page_records: cur.execute('INSERT INTO pages VALUES(?,?,?,?,?)',(r['id'],r['source_id'],r['pdf_page_number'],r['printed_page_number'],r['text']))
for r in chunk_records: cur.execute('INSERT INTO chunks VALUES(?,?,?,?,?,?)',(r['id'],r['source_id'],r['page_id'],r['pdf_page_number'],r['printed_page_number'],r['text']))
cur.execute("INSERT INTO chunks_fts(rowid,id,source_id,text) SELECT rowid,id,source_id,text FROM chunks")
con.commit(); con.close()
print(json.dumps({'sources':len(orig),'pdf_pages':len(page_records),'chunks':len(chunk_records),'db':str(DB)},ensure_ascii=False,indent=2))
