# RYE MCP Tool Contract v0.1

## search_rye
Input: query, optional source_ids, optional topic, optional max_results
Output: ranked evidence blocks with source_id, title, page, section, text_ref, score.

## get_rye_evidence
Input: evidence_ref
Output: source, page, section, passage.

## get_formula
Input: bread_name or formula_id
Output: structured formula preserving source stages and quantities.

## compare_sources
Input: topic, optional source_ids
Output: source-by-source claims; never silently merge conflicting claims.

## calculate_formula
Input: formula_id, target_flour_grams OR scale_factor
Output: scaled quantities derived mechanically from the documented formula.

## find_bread
Input: name, ingredient, region, rye_percentage, technology
Output: matching documented breads with provenance.
