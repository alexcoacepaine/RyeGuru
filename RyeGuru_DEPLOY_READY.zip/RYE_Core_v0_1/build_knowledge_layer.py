import json,re,sqlite3,hashlib
from pathlib import Path
ROOT=Path('/mnt/data/RYE_Core_v0_1'); pages=ROOT/'pages/pages.jsonl'; out=ROOT/'retrieval/knowledge_candidates.jsonl'
terms={
 'process':['zavarka','scald','soaker','opăreal','sourdough','maia','ferment','dosp','proof','coac','bake','frământ','mix'],
 'ingredient':['rye','secară','făină','flour','malt','solod','chimen','caraway','semin','seed','miere','honey','zahăr','sugar','cartof','potato'],
 'bread':['borod','morsk','latgal','belarus','pumpernickel','yubily','yubile','alaska','baltij','baltic']
}
pat={k:re.compile('|'.join(re.escape(x) for x in v),re.I) for k,v in terms.items()}
with pages.open(encoding='utf-8') as f:
    rows=[]
    for line in f:
        r=json.loads(line); text=r.get('text','')
        hits={k:sorted(set(m.group(0).lower() for m in p.finditer(text))) for k,p in pat.items()}
        hits={k:v for k,v in hits.items() if v}
        if hits:
            rows.append({'candidate_id':hashlib.sha1((r['source_id']+'|'+str(r.get('page_number'))).encode()).hexdigest()[:16], 'source_id':r['source_id'],'page_number':r.get('page_number'),'section':r.get('section'),'entities':hits,'status':'candidate_only'})
out.write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf-8')
print('knowledge candidates',len(rows))
