#!/usr/bin/env python3
"""Local RYE retrieval prototype. Returns source/page-grounded evidence only."""
import argparse, json, re, sqlite3
from pathlib import Path
DB=Path(__file__).with_name('rye.sqlite')

def fts(q):
    toks=re.findall(r'\S+', q.strip())
    return ' OR '.join('"'+t.replace('"','')+'"' for t in toks)

def search(q, limit=8, source=None):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    sql='''SELECT c.id,c.source_id,c.page_id,c.pdf_page,c.printed_page,c.text,
                  bm25(chunks_fts) AS score
           FROM chunks_fts JOIN chunks c ON chunks_fts.id=c.id
           WHERE chunks_fts MATCH ?'''
    args=[fts(q)]
    if source: sql+=' AND c.source_id=?'; args.append(source)
    sql+=' ORDER BY score LIMIT ?'; args.append(limit)
    rows=[dict(x) for x in con.execute(sql,args)]
    con.close()
    return rows

def evidence(rows):
    return [{
      'evidence_id':r['id'], 'source_id':r['source_id'],
      'page':r['printed_page'] or r['pdf_page'], 'pdf_page':r['pdf_page'],
      'text':r['text']
    } for r in rows]

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('query'); ap.add_argument('-n','--limit',type=int,default=8); ap.add_argument('--source'); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    out=evidence(search(a.query,a.limit,a.source))
    print(json.dumps({'query':a.query,'results':out},ensure_ascii=False,indent=2) if a.json else '\n\n'.join(f"[{x['source_id']} | p.{x['page']} | {x['evidence_id']}]\n{x['text'][:3500]}" for x in out))
